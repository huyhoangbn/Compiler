# Unicode properties

These files have been generated automatically.
Eventually, they should be removed from SCM.
